//
//  TimeInterval.swift
//  bemLembrar
//
//  Created by Henrique Semmer on 12/11/23.
//

import Foundation

extension TimeInterval {
    
    
}
