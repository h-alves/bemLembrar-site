//
//  Letters.swift
//  bemLembrar
//
//  Created by Henrique Semmer on 13/11/23.
//

import Foundation

class Letters {
    
    static let shared = Letters()
    
    var allLetters = ["A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z"]
}
